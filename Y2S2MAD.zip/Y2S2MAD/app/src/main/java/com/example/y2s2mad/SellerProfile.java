package com.example.y2s2mad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SellerProfile extends AppCompatActivity {

    EditText txtsellerName, txtemail, txtcontactNo, txttype, txtlocation, txtlanguages;
    Button btnSave;
    DatabaseReference dbRef;
    SellerReg selR;

    private void clearControls() {
        txtsellerName.setText("");
        txtemail.setText("");
        txtcontactNo.setText("");
        txttype.setText("");
        txtlocation.setText("");
        txtlanguages.setText("");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_profile);

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference updRef = FirebaseDatabase.getInstance().getReference().child("Student");
                updRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChild("Std1")){
                            try{
                                std.setsellerName(txtsellerName.getText().toString().trim());
                                std.setemail(txtemail.getText().toString().trim());
                                std.setcontactNo(Integer.parseInt(txtcontactNo.getText().toString().trim()));
                                std.settype(txtAdd.getText().toString().trim());
                                std.setlocation(txtAdd.getText().toString().trim());
                                std.setlanguages(txtlanguages.getText().toString().trim());



                                dbRef = FirebaseDatabase.getInstance().getReference().child("SellerReg").child("selR1");
                                dbRef.setValue(std);
                                clearControls();



                                Toast.makeText(getApplicationContext(), "Data Update Successfully", Toast.LENGTH_SHORT).show();
                            }



                            catch (NumberFormatException e){
                                Toast.makeText(getApplicationContext(), "Invalid Contact Number", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else
                            Toast.makeText(getApplicationContext(), "No Source to Update", Toast.LENGTH_SHORT).show();
                    }



                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {



                    }
                });
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference delRef = FirebaseDatabase.getInstance().getReference().child("SellerReg");
                delRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChild("selR1")) {
                            dbRef = FirebaseDatabase.getInstance().getReference().child("SellerReg").child("selR1");
                            dbRef.removeValue();
                            clearControls();
                            Toast.makeText(getApplicationContext(), "Data Deleted Successfully", Toast.LENGTH_SHORT).show();
                        }


                        else
                            Toast.makeText(getApplicationContext(), "No Source to Delete", Toast.LENGTH_SHORT).show();

                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });
    }
}