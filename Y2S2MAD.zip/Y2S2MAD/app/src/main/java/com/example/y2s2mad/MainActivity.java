package com.example.SellerReg;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Bundle;
public class MainActivity extends AppCompatActivity{

    EditText txtsellerName, txtemail, txtcontactNo, txttype, txtlocation, txtlanguages;
    Button btnSave;
    DatabaseReference dbRef;
    SellerReg selR;

    private void clearControls() {
        txtsellerName.setText("");
        txtemail.setText("");
        txtcontactNo.setText("");
        txttype.setText("");
        txtlocation.setText("");
        txtlanguages.setText("");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtsellerName = findViewById(R.id.EtsellerName);
        txtemail = findViewById(R.id.Etemail);
        txtcontactNo = findViewById(R.id.EtcontactNo);
        txttype = findViewById(R.id.Ettype);
        txtlocation = findViewById(R.id.Etlocation);
        txtlanguages = findViewById(R.id.Etlanguages);

        btnSave = findViewById(R.id.BtnSave);

        selR = new SellerReg();
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbRef = FirebaseDatabase.getInstance().getReference().child("SellerReg");


                try {
                    if (TextUtils.isEmpty(txtID.getText().toString()))
                        Toast.makeText(getApplicationContext(), "Please enter a name ", Toast.LENGTH_SHORT).show();
                    else if (TextUtils.isEmpty(txtName.getText().toString()))
                        Toast.makeText(getApplicationContext(), "Please enter a email", Toast.LENGTH_SHORT).show();
                    else if (TextUtils.isEmpty(txtAdd.getText().toString()))
                        Toast.makeText(getApplicationContext(), "Please enter a contact number", Toast.LENGTH_SHORT).show();
                    else if (TextUtils.isEmpty(txtAdd.getText().toString()))
                        Toast.makeText(getApplicationContext(), "Please enter a type of the shop", Toast.LENGTH_SHORT).show();
                    else if (TextUtils.isEmpty(txtAdd.getText().toString()))
                        Toast.makeText(getApplicationContext(), "Please enter a location of the shop ", Toast.LENGTH_SHORT).show();
                    else if (TextUtils.isEmpty(txtAdd.getText().toString()))
                        Toast.makeText(getApplicationContext(), "Please enter a languages", Toast.LENGTH_SHORT).show();


                    else {
                        selR.setsellerNameI(txtsellerName.getText().toString().trim());
                        selR.setemail(txtName.getText().toString().trim());
                        selR.setcontactNo(Integer.parseInt(txtConNo.getText().toString().trim()));
                        selR.settype(txtAdd.getText().toString().trim());
                        selR.setlocation(txtAdd.getText().toString().trim());
                        selR.setlanguages(txtAdd.getText().toString().trim());


                        dbRef.push().setValue(selR);


                        Toast.makeText(getApplicationContext(), "Data Saved Successfully", Toast.LENGTH_SHORT).show();
                        clearControls();
                    }


                } catch (NumberFormatException e) {
                    Toast.makeText(getApplicationContext(), "Invalid Contact Number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
