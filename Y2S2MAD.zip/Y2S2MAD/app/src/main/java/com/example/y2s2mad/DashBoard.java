package com.example.y2s2mad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DashBoard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);



        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseReference readRef = FirebaseDatabase.getInstance().getReference().child("SellerReg").child("selR");
                readRef.addListenerForSingleValueEvent(new ValueEventListener() {

                    txtsellerName=findViewById(R.id.EtsellerName);
                    txtemail = findViewById(R.id.Etemail);
                    txtcontactNo = findViewById(R.id.EtcontactNo);
                    txttype = findViewById(R.id.Ettype);
                    txtlocation = findViewById(R.id.Etlocation);
                    txtlanguages = findViewById(R.id.Etlanguages);

                    btnSave = findViewById(R.id.BtnSave);

                    selR = new SellerReg();

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChildren()) {
                            txtID.setText(dataSnapshot.child("sellerName").getValue().toString());
                            txtName.setText(dataSnapshot.child("email").getValue().toString());
                            txtAdd.setText(dataSnapshot.child("contactNo").getValue().toString());
                            txtConNo.setText(dataSnapshot.child("type").getValue().toString());
                            txtAdd.setText(dataSnapshot.child("location").getValue().toString());
                            txtAdd.setText(dataSnapshot.child("contactNo").getValue().toString());
                        }

                        else
                            Toast.makeText(getApplicationContext(), "No Source to Display", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

    }
}